class Dog { 
    age: number;
    name: string;
    breed: string;

    constructor (name: string) { 
        this.name = name;
    }
}
