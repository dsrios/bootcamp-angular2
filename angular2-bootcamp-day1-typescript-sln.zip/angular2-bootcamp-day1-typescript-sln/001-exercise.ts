function bark(sound: string) { 
    console.log(sound);
}
bark("Woof!");