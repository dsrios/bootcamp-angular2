class Dog {
    age: number;
    name: string;
    breed: string;
}