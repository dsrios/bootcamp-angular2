export class UserServiceConfig {
     userName = 'Config Initial Name';
}
