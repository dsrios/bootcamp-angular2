import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
    UserName= "Felipe Jarmillo"
    constructor() { }
}