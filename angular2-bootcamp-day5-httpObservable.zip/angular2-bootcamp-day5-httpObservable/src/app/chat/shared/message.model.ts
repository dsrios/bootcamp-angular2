export class Message{
    public author:string;
    public text:string;
    
    constructor(author:string,text:string){
        this.author = author;
        this.text = text;
    }
}