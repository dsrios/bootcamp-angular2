export class Person {
	constructor(
		public id: number,
		public name: string,
		public alterEgo?: string
	) { }
}
