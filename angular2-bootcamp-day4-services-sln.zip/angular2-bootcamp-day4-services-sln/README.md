# Steps 
1. Create the interface of the calculator servicie
    * src/app/calculator/shared/definitions/calculator.service.ts
2. The calculator service will implement the interface we just created
    * src/app/calculator/shared/calculator.service.ts
3. Remove the dependency from the concrete implementation and add it to the interface we just created
    * src/app/calculator/calculator.component.ts
    * src/app/calculator/button/buttons
4. Configure the provider to resolve the dependency ICalculator with the CalculatorService
    * src/app/calculator/calculator.module.ts
    * ***Note*** : we are not able to use an interface so we use a string name.
5. Use the @Inject in the components we want angular to inject the interface
    * src/app/calculator/calculator.component.ts
    * src/app/calculator/button/buttons

    :tada: Check it works!!

# Create a factory
1. Create a Core Module in the root
2. Create a interface 'ILogger' with the function 'logError'
3. Create two implementations of the 'ILogger' interface
    * src/app/core/logger.service.ts 
    * src/app/core/logger-dev.service.ts 
4. Create a custom provider in the core module.
    * src/app/core/logger.provider.ts
5. Configure the core module providers to resolve the logger dependency
    * src/app/core/core.module.ts
6. Inject the ILogger to the CalculatorService
    * src/app/core/calculator
7. add the log routine in the catch of the calculator service
    * src/app/core/calculator
8. Import the CoreModule in the AppModule
    * src/app/AppModule