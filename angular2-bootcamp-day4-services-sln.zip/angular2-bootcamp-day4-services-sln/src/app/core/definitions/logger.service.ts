export interface ILogger {
    logError(error: string);
}


